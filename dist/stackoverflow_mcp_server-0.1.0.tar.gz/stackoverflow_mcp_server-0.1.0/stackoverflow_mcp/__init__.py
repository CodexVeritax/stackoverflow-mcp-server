"""Veritax Stackoverflow MCP Server.

A Model Context Protocol (MCP) server for accessing Stackoverflow question.
"""

__version__ = "0.1.0" 